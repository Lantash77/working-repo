# -*- coding: utf-8 -*-

"""
    VIKI Rakuten® addon Add-on
"""

from . import lang_sel
from . import cache